class PlanFix {
  final String ident;
  final String via;
  final int? altFt;
  const PlanFix(this.ident, this.via, this.altFt);
}

class SimbriefPlan {
  final String origin, destination, route, units;
  final String sid, star, depRunway, arrRunway;
  final int cruiseAltFt, costIndex;
  final double zfw, blockFuel, reserve;
  final List<PlanFix> fixes;
  const SimbriefPlan({
    required this.origin, required this.destination, required this.route,
    required this.units, required this.sid, required this.star,
    required this.depRunway, required this.arrRunway,
    required this.cruiseAltFt, required this.costIndex,
    required this.zfw, required this.blockFuel, required this.reserve,
    required this.fixes,
  });

  static double _d(dynamic v) => double.tryParse('${v ?? ''}') ?? 0;
  static int _i(dynamic v) => (double.tryParse('${v ?? ''}') ?? 0).round();
  static String _s(dynamic v) => '${v ?? ''}'.trim();

  factory SimbriefPlan.fromJson(Map<String, dynamic> j) {
    final g = (j['general'] ?? {}) as Map<String, dynamic>;
    final o = (j['origin'] ?? {}) as Map<String, dynamic>;
    final d = (j['destination'] ?? {}) as Map<String, dynamic>;
    final w = (j['weights'] ?? {}) as Map<String, dynamic>;
    final f = (j['fuel'] ?? {}) as Map<String, dynamic>;
    final p = (j['params'] ?? {}) as Map<String, dynamic>;
    final nav = (j['navlog'] ?? {}) as Map<String, dynamic>;
    final raw = nav['fix'];
    final list = raw is List ? raw : (raw is Map ? [raw] : const []);
    final fixes = <PlanFix>[
      for (final x in list)
        if (x is Map &&
            _s(x['ident']).isNotEmpty &&
            !{'TOC', 'TOD'}.contains(_s(x['ident'])) &&
            _s(x['ident']) != _s(o['icao_code']) &&
            _s(x['ident']) != _s(d['icao_code']))
          PlanFix(_s(x['ident']), _s(x['via_airway']), _i(x['altitude_feet'])),
    ];
    return SimbriefPlan(
      origin: _s(o['icao_code']),
      destination: _s(d['icao_code']),
      route: _s(g['route']),
      units: _s(p['units']).isEmpty ? 'KGS' : _s(p['units']),
      sid: _s(g['sid_ident']),
      star: _s(g['star_ident']),
      depRunway: _s(o['plan_rwy']),
      arrRunway: _s(d['plan_rwy']),
      cruiseAltFt: _i(g['initial_altitude']),
      costIndex: _i(g['costindex']),
      zfw: _d(w['est_zfw']),
      blockFuel: _d(f['plan_ramp']),
      reserve: _d(f['reserve']),
      fixes: fixes,
    );
  }
}
