import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../core/haptics_service.dart' as hx;

/// Trackpad area: pan produces cursor deltas (dx, dy in px).
class CcdTouchPad extends StatelessWidget {
  final void Function(Offset delta) onMove;
  final VoidCallback onEnter; // tap = click
  const CcdTouchPad({super.key, required this.onMove, required this.onEnter});

  @override
  Widget build(BuildContext context) => GestureDetector(
        onPanUpdate: (d) => onMove(d.delta),
        onTap: () { hx.Feedback.push(); onEnter(); },
        child: Container(
          decoration: BoxDecoration(
            color: const Color(0xFF1B1E22),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: const Color(0xFF4A5057), width: 2),
          ),
          alignment: Alignment.center,
          child: const Text('CCD TRACKPAD', style: TextStyle(color: Colors.white24, letterSpacing: 2)),
        ),
      );
}

/// Concentric rotary: outer ring = RANGE, inner knob = DATA. Center = PUSH ENTER.
/// A detent fires every [detentDeg] degrees of rotation, with haptic + sound.
class ConcentricKnob extends StatefulWidget {
  final void Function(int steps) onOuter; // +/- detents
  final void Function(int steps) onInner;
  final VoidCallback onPush;
  const ConcentricKnob({super.key, required this.onOuter, required this.onInner, required this.onPush});
  @override
  State<ConcentricKnob> createState() => _ConcentricKnobState();
}

class _ConcentricKnobState extends State<ConcentricKnob> {
  static const detentDeg = 15.0;
  double _outer = 0, _inner = 0;
  double _accum = 0;
  double? _last;
  bool? _isOuter;

  double _ang(Offset p, Size s) => math.atan2(p.dy - s.height / 2, p.dx - s.width / 2) * 180 / math.pi;

  @override
  Widget build(BuildContext context) => LayoutBuilder(builder: (ctx, c) {
        final size = Size.square(math.min(c.maxWidth, c.maxHeight));
        final R = size.width / 2;
        return Center(
          child: SizedBox.fromSize(
            size: size,
            child: GestureDetector(
              onPanStart: (d) {
                final r = (d.localPosition - Offset(R, R)).distance;
                if (r < R * 0.28) { _isOuter = null; return; }
                _isOuter = r > R * 0.62;
                _last = _ang(d.localPosition, size);
                _accum = 0;
              },
              onPanUpdate: (d) {
                if (_isOuter == null || _last == null) return;
                final a = _ang(d.localPosition, size);
                var delta = a - _last!;
                if (delta > 180) delta -= 360;
                if (delta < -180) delta += 360;
                _last = a;
                _accum += delta;
                setState(() { if (_isOuter!) { _outer += delta; } else { _inner += delta; } });
                while (_accum.abs() >= detentDeg) {
                  final s = _accum.sign.toInt();
                  _accum -= s * detentDeg;
                  hx.Feedback.detent();
                  (_isOuter! ? widget.onOuter : widget.onInner)(s);
                }
              },
              onPanEnd: (_) { _isOuter = null; _last = null; },
              child: Stack(alignment: Alignment.center, children: [
                Transform.rotate(angle: _outer * math.pi / 180,
                    child: CustomPaint(size: size, painter: _RingPainter(1.0, const Color(0xFF2B3036), 'RANGE'))),
                Transform.rotate(angle: _inner * math.pi / 180,
                    child: CustomPaint(size: size, painter: _RingPainter(0.6, const Color(0xFF3A4048), 'DATA'))),
                GestureDetector(
                  onTap: () { hx.Feedback.push(); widget.onPush(); },
                  child: Container(
                    width: R * 0.5, height: R * 0.5,
                    decoration: const BoxDecoration(shape: BoxShape.circle, color: Color(0xFF111316)),
                    alignment: Alignment.center,
                    child: Text('ENTER', style: TextStyle(color: Colors.white70, fontSize: R * 0.1)),
                  ),
                ),
              ]),
            ),
          ),
        );
      });
}

class _RingPainter extends CustomPainter {
  final double scale; final Color c; final String label;
  _RingPainter(this.scale, this.c, this.label);
  @override
  void paint(Canvas canvas, Size s) {
    final ctr = s.center(Offset.zero);
    final r = s.width / 2 * scale;
    canvas.drawCircle(ctr, r, Paint()..color = c);
    canvas.drawCircle(ctr, r, Paint()..color = Colors.white24..style = PaintingStyle.stroke..strokeWidth = 2);
    for (var i = 0; i < 24; i++) { // knurling ticks
      final a = i * math.pi / 12;
      canvas.drawLine(ctr + Offset(math.cos(a), math.sin(a)) * (r * 0.9),
          ctr + Offset(math.cos(a), math.sin(a)) * r, Paint()..color = Colors.white30..strokeWidth = 2);
    }
    final tp = TextPainter(text: TextSpan(text: label, style: TextStyle(color: Colors.white38, fontSize: r * 0.09)), textDirection: TextDirection.ltr)..layout();
    tp.paint(canvas, Offset(ctr.dx - tp.width / 2, ctr.dy - r * 0.8));
  }
  @override
  bool shouldRepaint(_) => false;
}
