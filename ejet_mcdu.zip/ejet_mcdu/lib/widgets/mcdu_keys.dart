import 'package:flutter/material.dart';
import '../core/haptics_service.dart' as hx;

/// Dark key with light legend; pulses amber when [glow] (trainer highlight).
class McduKey extends StatefulWidget {
  final String id, label;
  final bool glow, lsk, round;
  final void Function(String id) onPress;
  final VoidCallback? onLong;
  const McduKey({super.key, required this.id, String? label, required this.glow, required this.onPress,
      this.lsk = false, this.round = false, this.onLong})
      : label = label ?? id;
  @override
  State<McduKey> createState() => _McduKeyState();
}

class _McduKeyState extends State<McduKey> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 700))..repeat(reverse: true);
  @override
  void dispose() { _c.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final key = GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTapDown: (_) { widget.lsk ? hx.Feedback.lsk() : hx.Feedback.key(); widget.onPress(widget.id); },
      onLongPress: widget.onLong,
      child: AnimatedBuilder(
        animation: _c,
        builder: (_, __) => Container(
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: const Color(0xFF1C1C1C),
            shape: widget.round ? BoxShape.circle : BoxShape.rectangle,
            borderRadius: widget.round ? null : BorderRadius.circular(5),
            border: Border.all(color: widget.glow ? Color.lerp(Colors.amber.shade200, Colors.amber, _c.value)! : const Color(0xFF5B6168), width: widget.glow ? 2.5 : 1),
            boxShadow: widget.glow ? [BoxShadow(color: Colors.amber.withOpacity(0.15 + 0.55 * _c.value), blurRadius: 14)] : null,
          ),
          child: FittedBox(child: Padding(padding: const EdgeInsets.all(5),
              child: Text(widget.label, textAlign: TextAlign.center, style: const TextStyle(color: Color(0xFFEDEDED), fontWeight: FontWeight.w700)))),
        ),
      ),
    );
    return Padding(padding: const EdgeInsets.all(2.5), child: widget.round ? Center(child: AspectRatio(aspectRatio: 1, child: key)) : key);
  }
}

/// Honeywell MCDU key layout: INIT/PREV/NEXT/CLR/→/EXEC/+-, AIRP/VOR/NDB/FIX/LAT LON/RADIO,
/// 6-column alphabet block and round numeric pad.
class McduKeypad extends StatelessWidget {
  final void Function(String) onKey; // receives every id incl. LSKs when showLsk
  final Set<String> highlights;
  final bool showLsk; // extra L1-R6 rows when the LSKs are not pinned beside the display
  const McduKeypad({super.key, required this.onKey, required this.highlights, this.showLsk = false});

  static const fn1 = ['INIT', 'PREV', 'NEXT', 'CLR', '→', 'EXEC', '+/-'];
  static const fn2 = ['AIRP', 'VOR', 'NDB', 'FIX', 'LATLON', 'RADIO'];
  static const letters = [
    ['A', 'B', 'C', 'D', 'E', 'F'],
    ['G', 'H', 'I', 'J', 'K', 'L'],
    ['M', 'N', 'O', 'P', 'Q', 'R'],
    ['', 'S', 'T', 'U', 'V', 'W'],
    ['', 'X', 'Y', 'Z', '←', 'DEL'],
  ];
  static const nums = [
    <String>[],
    ['1', '2', '3'],
    ['4', '5', '6'],
    ['7', '8', '9'],
    ['.', '0', '-'],
  ];

  Widget _key(String id, {bool lsk = false, bool round = false}) {
    if (id.isEmpty) return const SizedBox.shrink();
    final glow = highlights.contains(id) || (highlights.contains('ALPHANUM') && id.length == 1);
    return McduKey(
      id: id, label: id == 'LATLON' ? 'LAT\nLON' : id, glow: glow, lsk: lsk, round: round, onPress: onKey,
      onLong: id == 'CLR' ? () => onKey('CLR_ALL') : null,
    );
  }

  Widget _row(List<String> ids, int cols, {bool lsk = false, bool round = false}) => Expanded(
        child: Row(children: [
          for (var j = 0; j < cols; j++) Expanded(child: j < ids.length ? _key(ids[j], lsk: lsk, round: round) : const SizedBox.shrink()),
        ]),
      );

  @override
  Widget build(BuildContext context) {
    final lskL = [for (var i = 1; i <= 6; i++) 'L$i'];
    final lskR = [for (var i = 1; i <= 6; i++) 'R$i'];
    return Container(
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(color: const Color(0xFF7E868E), borderRadius: BorderRadius.circular(10)),
      child: Column(children: [
        _row(fn1, 7),
        _row(fn2, 6),
        Expanded(
          flex: 5,
          child: Row(children: [
            Expanded(flex: 6, child: Column(children: [for (final r in letters) _row(r, 6)])),
            const SizedBox(width: 6),
            Expanded(flex: 3, child: Column(children: [for (final r in nums) _row(r, 3, round: true)])),
          ]),
        ),
        if (showLsk) ...[_row(lskL, 6, lsk: true), _row(lskR, 6, lsk: true)],
      ]),
    );
  }
}
