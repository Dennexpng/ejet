import 'package:flutter/material.dart';
import '../core/haptics_service.dart' as hx;

/// A key that pulses amber when [glow] is true (trainer highlight).
class McduKey extends StatefulWidget {
  final String id, label;
  final bool glow, lsk;
  final void Function(String id) onPress;
  final VoidCallback? onLong;
  const McduKey({super.key, required this.id, String? label, required this.glow, required this.onPress, this.lsk = false, this.onLong})
      : label = label ?? id;
  @override
  State<McduKey> createState() => _McduKeyState();
}

class _McduKeyState extends State<McduKey> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 700))..repeat(reverse: true);
  @override
  void dispose() { _c.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.all(2),
        child: GestureDetector(
          onTapDown: (_) { widget.lsk ? hx.Feedback.lsk() : hx.Feedback.key(); widget.onPress(widget.id); },
          onLongPress: widget.onLong,
          child: AnimatedBuilder(
            animation: _c,
            builder: (_, __) => Container(
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: const Color(0xFF2A2E33),
                borderRadius: BorderRadius.circular(6),
                border: Border.all(color: widget.glow ? Color.lerp(Colors.amber.shade200, Colors.amber, _c.value)! : const Color(0xFF50575F), width: widget.glow ? 2.5 : 1),
                boxShadow: widget.glow ? [BoxShadow(color: Colors.amber.withOpacity(0.15 + 0.55 * _c.value), blurRadius: 14)] : null,
              ),
              child: FittedBox(child: Padding(padding: const EdgeInsets.all(4), child: Text(widget.label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600)))),
            ),
          ),
        ),
      );
}

class McduKeypad extends StatelessWidget {
  /// Receives every key id, including LSKs ("L1".."R6"); the screen routes them.
  final void Function(String) onKey;
  final Set<String> highlights;
  final bool showLsk;
  const McduKeypad({super.key, required this.onKey, required this.highlights, this.showLsk = true});

  static const fn = ['INIT', 'FPLN', 'PERF', 'NAV', 'RADIO', 'PROG', 'MENU', 'DIR', 'PREV', 'NEXT'];
  static const alpha = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  static const nums = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '.', '0', '/', 'SP', 'DEL', 'CLR'];

  // Fills available space exactly: rows of Expanded keys.
  Widget _block(List<String> ids, int cols, {bool lsk = false}) {
    final rows = <Widget>[];
    for (var i = 0; i < ids.length; i += cols) {
      final slice = ids.skip(i).take(cols).toList();
      rows.add(Expanded(
        child: Row(children: [
          for (var j = 0; j < cols; j++)
            Expanded(
              child: j < slice.length
                  ? McduKey(
                      id: slice[j], lsk: lsk, onPress: onKey,
                      glow: highlights.contains(slice[j]) || (highlights.contains('ALPHANUM') && slice[j].length == 1),
                      onLong: slice[j] == 'CLR' ? () => onKey('CLR_ALL') : null)
                  : const SizedBox.shrink(),
            ),
        ]),
      ));
    }
    return Column(children: rows);
  }

  @override
  Widget build(BuildContext context) {
    final lskL = [for (var i = 1; i <= 6; i++) 'L$i'];
    final lskR = [for (var i = 1; i <= 6; i++) 'R$i'];
    return Column(children: [
      Expanded(flex: 4, child: _block(fn, 5)),
      Expanded(flex: 12, child: _block(alpha.split(''), 7)),
      Expanded(flex: 9, child: _block(nums, 5)),
      if (showLsk) ...[
        Expanded(flex: 3, child: _block(lskL, 6, lsk: true)),
        Expanded(flex: 3, child: _block(lskR, 6, lsk: true)),
      ],
    ]);
  }
}
