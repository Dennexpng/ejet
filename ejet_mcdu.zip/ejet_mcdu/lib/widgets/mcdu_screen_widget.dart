import 'package:flutter/material.dart';
import '../fms/fms_state_machine.dart';

const _fontFamily = 'PrimusMono'; // falls back to monospace if asset not bundled

Color mcduColor(McduColor c) => switch (c) {
      McduColor.green => const Color(0xFF4CF04F),
      McduColor.yellow => const Color(0xFFFFD84A),
      McduColor.cyan => const Color(0xFF29E6FF),
      McduColor.magenta => const Color(0xFFFF4FE8),
      McduColor.white => const Color(0xFFEFEFEF),
      McduColor.amber => const Color(0xFFFFA000),
    };

/// Honeywell-style MCDU: grey bezel, black glass, 6 dash LSKs per side.
class McduScreen extends StatelessWidget {
  final McduFrame frame;
  final bool showLsk;
  final void Function(bool left, int n)? onLsk;
  final Set<String> highlights;
  const McduScreen({super.key, required this.frame, this.showLsk = false, this.onLsk, this.highlights = const {}});

  @override
  Widget build(BuildContext context) {
    final glass = Container(
      decoration: BoxDecoration(
        color: Colors.black,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0xFF15181B), width: 3),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(15),
        child: RepaintBoundary(child: CustomPaint(painter: McduPainter(frame), size: Size.infinite)),
      ),
    );
    return Container(
      padding: const EdgeInsets.all(6),
      decoration: BoxDecoration(
        gradient: const LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter,
            colors: [Color(0xFF9AA1A8), Color(0xFF7C848C)]),
        borderRadius: BorderRadius.circular(12),
      ),
      child: showLsk
          ? Row(children: [_col(true), const SizedBox(width: 4), Expanded(child: glass), const SizedBox(width: 4), _col(false)])
          : glass,
    );
  }

  // 14 equal slots to align with painter rows; LSK n sits on data row 2n.
  Widget _col(bool left) => SizedBox(
        width: 32,
        child: Column(children: [
          for (var i = 0; i < 14; i++)
            Expanded(
              child: (i >= 2 && i <= 12 && i.isEven)
                  ? _LskButton(glow: highlights.contains('${left ? 'L' : 'R'}${i ~/ 2}'), onTap: () => onLsk?.call(left, i ~/ 2))
                  : const SizedBox.shrink(),
            ),
        ]),
      );
}

class _LskButton extends StatefulWidget {
  final bool glow; final VoidCallback onTap;
  const _LskButton({required this.glow, required this.onTap});
  @override
  State<_LskButton> createState() => _LskButtonState();
}

class _LskButtonState extends State<_LskButton> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 700))..repeat(reverse: true);
  @override
  void dispose() { _c.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTapDown: (_) => widget.onTap(),
        child: AnimatedBuilder(
          animation: _c,
          builder: (_, __) => Container(
            margin: const EdgeInsets.symmetric(vertical: 3, horizontal: 2),
            decoration: BoxDecoration(
              color: const Color(0xFF1A1A1A),
              borderRadius: BorderRadius.circular(4),
              border: Border.all(color: widget.glow ? Color.lerp(Colors.amber.shade200, Colors.amber, _c.value)! : const Color(0xFF55595E), width: widget.glow ? 2.5 : 1),
              boxShadow: widget.glow ? [BoxShadow(color: Colors.amber.withOpacity(0.2 + 0.5 * _c.value), blurRadius: 12)] : null,
            ),
            alignment: Alignment.center,
            child: Container(width: 14, height: 3, color: const Color(0xFFE6DDB4)),
          ),
        ),
      );
}

class McduPainter extends CustomPainter {
  final McduFrame f;
  McduPainter(this.f);
  static const cols = 24, rows = 14;

  TextPainter _tp(String t, Color c, double fs) => TextPainter(
        text: TextSpan(text: t, style: TextStyle(color: c, fontSize: fs, fontFamily: _fontFamily, fontFamilyFallback: const ['RobotoMono', 'monospace'], height: 1.0)),
        textDirection: TextDirection.ltr,
      )..layout();

  @override
  void paint(Canvas canvas, Size s) {
    final padX = s.width * 0.03;
    final w = s.width - 2 * padX;
    final rowH = s.height / rows;
    final big = (w / cols / 0.6).clamp(8.0, rowH * 0.85);
    final small = big * 0.72;

    void text(String t, double y, {required bool left, required Color c, required double fs, bool center = false}) {
      if (t.isEmpty) return;
      var tp = _tp(t, c, fs);
      final limit = w * (center ? 1.0 : 0.62);
      if (tp.width > limit) tp = _tp(t, c, fs * limit / tp.width); // shrink to fit
      final x = center ? (s.width - tp.width) / 2 : (left ? padX : s.width - padX - tp.width);
      tp.paint(canvas, Offset(x, y + (rowH - tp.height) / 2));
    }

    text(f.title, 0, left: true, c: mcduColor(McduColor.white), fs: big, center: true);
    text(f.pageNo, 0, left: false, c: mcduColor(McduColor.white), fs: small);

    for (var i = 0; i < 6; i++) {
      final r = f.rows[i];
      final yLabel = (1 + i * 2) * rowH;
      final yData = (2 + i * 2) * rowH;
      text(r.lLabel, yLabel + rowH * 0.25, left: true, c: mcduColor(McduColor.white), fs: small);
      text(r.rLabel, yLabel + rowH * 0.25, left: false, c: mcduColor(McduColor.white), fs: small);
      text(r.lData, yData, left: true, c: mcduColor(r.lColor), fs: big);
      text(r.rData, yData, left: false, c: mcduColor(r.rColor), fs: big);
    }

    if (f.message != null) {
      text(f.message!, 12 * rowH + rowH * 0.15, left: true, c: mcduColor(McduColor.amber), fs: small);
    }
    // Scratchpad with cursor bar
    final sp = _tp(f.scratchpad.isEmpty ? ' ' : f.scratchpad, mcduColor(McduColor.white), big);
    final sy = 13 * rowH + (rowH - sp.height) / 2;
    sp.paint(canvas, Offset(padX, sy));
    final cx = padX + (f.scratchpad.isEmpty ? 0 : sp.width) + 2;
    canvas.drawRect(Rect.fromLTWH(cx, sy, 2, sp.height), Paint()..color = mcduColor(McduColor.white));
  }

  @override
  bool shouldRepaint(McduPainter o) => true;
}
