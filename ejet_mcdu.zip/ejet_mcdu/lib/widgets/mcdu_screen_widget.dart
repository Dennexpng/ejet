import 'package:flutter/material.dart';
import '../fms/fms_state_machine.dart';

const _fontFamily = 'PrimusMono'; // falls back to monospace if asset not bundled

Color mcduColor(McduColor c) => switch (c) {
      McduColor.green => const Color(0xFF3BFF4A),
      McduColor.cyan => const Color(0xFF29E6FF),
      McduColor.magenta => const Color(0xFFFF4FE8),
      McduColor.white => const Color(0xFFF2F2F2),
      McduColor.amber => const Color(0xFFFFB400),
    };

/// 24 columns x 14 rows: title, 6x(label+data), scratchpad.
class McduScreen extends StatelessWidget {
  final McduFrame frame;
  final bool showLsk;
  final void Function(bool left, int n)? onLsk;
  final Set<String> highlights;
  const McduScreen({super.key, required this.frame, this.showLsk = false, this.onLsk, this.highlights = const {}});

  @override
  Widget build(BuildContext context) {
    final screen = ClipRRect(
      borderRadius: BorderRadius.circular(10),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.black,
          border: Border.all(color: const Color(0xFF3A3F45), width: 3),
          borderRadius: BorderRadius.circular(10),
        ),
        child: RepaintBoundary(child: CustomPaint(painter: McduPainter(frame), size: Size.infinite)),
      ),
    );
    if (!showLsk) return screen;
    return Row(children: [
      _col(true),
      const SizedBox(width: 4),
      Expanded(child: screen),
      const SizedBox(width: 4),
      _col(false),
    ]);
  }

  // 14 equal slots to align with painter rows; LSK n sits on data row 2n.
  Widget _col(bool left) => SizedBox(
        width: 40,
        child: Column(children: [
          for (var i = 0; i < 14; i++)
            Expanded(
              child: (i >= 2 && i <= 12 && i.isEven)
                  ? _LskButton(id: '${left ? 'L' : 'R'}${i ~/ 2}', glow: highlights.contains('${left ? 'L' : 'R'}${i ~/ 2}'),
                      onTap: () => onLsk?.call(left, i ~/ 2))
                  : const SizedBox.shrink(),
            ),
        ]),
      );
}

class _LskButton extends StatefulWidget {
  final String id; final bool glow; final VoidCallback onTap;
  const _LskButton({required this.id, required this.glow, required this.onTap});
  @override
  State<_LskButton> createState() => _LskButtonState();
}

class _LskButtonState extends State<_LskButton> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 700))..repeat(reverse: true);
  @override
  void dispose() { _c.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => GestureDetector(
        onTapDown: (_) => widget.onTap(),
        child: AnimatedBuilder(
          animation: _c,
          builder: (_, __) => Container(
            margin: const EdgeInsets.symmetric(vertical: 2),
            decoration: BoxDecoration(
              color: const Color(0xFF23272C),
              borderRadius: BorderRadius.circular(4),
              border: Border.all(color: widget.glow ? Color.lerp(Colors.amber.shade200, Colors.amber, _c.value)! : const Color(0xFF4A5057), width: widget.glow ? 2.5 : 1),
              boxShadow: widget.glow ? [BoxShadow(color: Colors.amber.withOpacity(0.2 + 0.5 * _c.value), blurRadius: 12)] : null,
            ),
            alignment: Alignment.center,
            child: Text(widget.id, style: const TextStyle(color: Colors.white70, fontSize: 10)),
          ),
        ),
      );
}

class McduPainter extends CustomPainter {
  final McduFrame f;
  McduPainter(this.f);
  static const cols = 24, rows = 14;

  @override
  void paint(Canvas canvas, Size s) {
    final padX = s.width * 0.02;
    final w = s.width - 2 * padX;
    final rowH = s.height / rows;
    final big = (w / cols / 0.6).clamp(8.0, rowH * 0.85);
    final small = big * 0.7;

    void text(String t, double y, {required bool left, required Color c, required double fs, bool center = false}) {
      if (t.isEmpty) return;
      final tp = TextPainter(
        text: TextSpan(text: t, style: TextStyle(color: c, fontSize: fs, fontFamily: _fontFamily, fontFamilyFallback: const ['RobotoMono', 'monospace'], height: 1.0)),
        textDirection: TextDirection.ltr,
      )..layout(maxWidth: w * (center ? 1 : 0.55));
      final x = center ? (s.width - tp.width) / 2 : (left ? padX : s.width - padX - tp.width);
      tp.paint(canvas, Offset(x, y + (rowH - tp.height) / 2));
    }

    // Title + page number
    text(f.title, 0, left: true, c: mcduColor(McduColor.white), fs: big, center: true);
    text(f.pageNo, 0, left: false, c: mcduColor(McduColor.white), fs: small);

    for (var i = 0; i < 6; i++) {
      final r = f.rows[i];
      final yLabel = (1 + i * 2) * rowH;
      final yData = (2 + i * 2) * rowH;
      text(r.lLabel, yLabel + rowH * 0.2, left: true, c: mcduColor(McduColor.white), fs: small);
      text(r.rLabel, yLabel + rowH * 0.2, left: false, c: mcduColor(McduColor.white), fs: small);
      text(r.lData, yData, left: true, c: mcduColor(r.lColor), fs: big);
      text(r.rData, yData, left: false, c: mcduColor(r.rColor), fs: big);
    }

    // Message line + scratchpad
    if (f.message != null) {
      text(f.message!, 12 * rowH + rowH * 0.1, left: true, c: mcduColor(McduColor.amber), fs: small);
    }
    text(f.scratchpad.isEmpty ? '' : f.scratchpad, 13 * rowH, left: true, c: mcduColor(McduColor.white), fs: big);
    if (f.scratchpad.isEmpty) {
      canvas.drawRect(Rect.fromLTWH(padX, 13 * rowH + rowH * 0.2, big * 0.6 * 4, rowH * 0.6),
          Paint()..color = mcduColor(McduColor.white)..style = PaintingStyle.stroke..strokeWidth = 1);
    }
  }

  @override
  bool shouldRepaint(McduPainter o) => true; // frame is rebuilt per notify
}
