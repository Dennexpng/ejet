import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/haptics_service.dart' as hx;
import '../fms/fms_state_machine.dart';
import '../services/nav_database.dart';
import '../services/perf_tables.dart';
import '../services/simbrief_service.dart';
import '../trainer/trainer_engine.dart';
import '../widgets/ccd_touch_pad.dart';
import '../widgets/mcdu_keys.dart';
import '../widgets/mcdu_screen_widget.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  TrainerEngine? trainer; // null = sandbox
  bool pinLsk = true;
  String lastCcd = 'DISPLAY: MFD';
  Offset cursor = Offset.zero;
  final _sb = SimbriefService();

  FmsState get fms => context.read<FmsState>();

  void _toggleMode() => setState(() {
        if (trainer == null) { fms.reset(); trainer = TrainerEngine(fms); }
        else { trainer!.dispose(); trainer = null; }
      });

  void _onKey(String id) {
    final m = RegExp(r'^([LR])([1-6])$').firstMatch(id);
    if (m != null) { fms.pressLsk(m.group(1) == 'L', int.parse(m.group(2)!)); }
    else if (id == 'CLR_ALL') { fms.clearHold(); }
    else { fms.pressKey(id); }
    final msg = fms.message;
    if (msg == 'INVALID ENTRY') hx.Feedback.error();
  }

  Future<void> _loadData() async {
    final r = await FilePicker.platform.pickFiles();
    final path = r?.files.single.path;
    if (path == null) return;
    try {
      if (path.endsWith('.json')) {
        fms.perfTables = await PerfTables.loadFile(path);
      } else {
        final db = fms.nav ?? NavDatabase();
        await db.loadFile(path);
        fms.nav = db;
      }
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Loaded ${path.split('/').last}')));
    } catch (e) {
      hx.Feedback.error();
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Load failed: $e')));
    }
  }

  Future<void> _simbrief() async {
    final ctl = TextEditingController();
    final id = await showDialog<String>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('SimBrief Pilot ID'),
        content: TextField(controller: ctl, keyboardType: TextInputType.number, autofocus: true),
        actions: [TextButton(onPressed: () => Navigator.pop(c, ctl.text), child: const Text('IMPORT'))],
      ),
    );
    if (id == null || !mounted) return;
    try {
      final plan = await _sb.fetchLatest(id);
      fms.importPlan(plan);
    } catch (e) {
      hx.Feedback.error();
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('SimBrief: $e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final f = context.watch<FmsState>();
    final t = trainer;
    final hl = t?.highlights ?? <String>{};
    final mq = MediaQuery.of(context);
    const corner = 14.0; // extra inset for S26 rounded corners
    final pad = EdgeInsets.fromLTRB(mq.viewPadding.left + corner, mq.viewPadding.top + 6, mq.viewPadding.right + corner, mq.viewPadding.bottom + 6);

    final screen = McduScreen(frame: f.frame, showLsk: pinLsk || mq.orientation == Orientation.landscape, onLsk: (l, n) => _onKey('${l ? 'L' : 'R'}$n'), highlights: hl);

    return ListenableBuilder(
      listenable: t ?? f,
      builder: (context, _) => Scaffold(
      backgroundColor: const Color(0xFF0E1013),
      body: Padding(
        padding: pad,
        child: Column(children: [
          _topBar(t),
          if (t?.popup != null) _popup(t!),
          Expanded(
            child: OrientationBuilder(builder: (ctx, o) => o == Orientation.portrait
                ? Column(children: [
                    Expanded(child: screen),
                    const SizedBox(height: 6),
                    Expanded(child: _tabs(hl, pinned: pinLsk)),
                  ])
                : Row(children: [
                    Expanded(flex: 5, child: screen),
                    const SizedBox(width: 8),
                    Expanded(flex: 5, child: Column(children: [
                      Expanded(flex: 5, child: _ccd()),
                      const SizedBox(height: 6),
                      Expanded(flex: 6, child: McduKeypad(onKey: _onKey, highlights: hl, showLsk: false)),
                    ])),
                  ])),
          ),
        ]),
      ),
    ));
  }

  Widget _topBar(TrainerEngine? t) => Column(children: [
        Row(children: [
          ChoiceChip(label: Text(t == null ? 'SANDBOX' : 'TRAINER'), selected: t != null, onSelected: (_) => _toggleMode()),
          const SizedBox(width: 8),
          ActionChip(label: const Text('SIMBRIEF'), onPressed: _simbrief),
          const SizedBox(width: 6),
          ActionChip(label: const Text('DATA'), onPressed: _loadData),
          const Spacer(),
          const Text('LSK', style: TextStyle(color: Colors.white54, fontSize: 12)),
          Switch(value: pinLsk, onChanged: (v) => setState(() => pinLsk = v)),
        ]),
        if (t != null)
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(8),
            margin: const EdgeInsets.only(bottom: 4),
            decoration: BoxDecoration(color: const Color(0xFF1F2A33), borderRadius: BorderRadius.circular(8), border: Border.all(color: Colors.amber.withOpacity(0.6))),
            child: t.finished
                ? Row(children: [const Expanded(child: Text('PREFLIGHT COMPLETE', style: TextStyle(color: Colors.greenAccent))), TextButton(onPressed: t.restart, child: const Text('RESTART'))])
                : Text('${t.step.title}\n${t.step.instruction}', style: const TextStyle(color: Colors.white, fontSize: 12)),
          ),
      ]);

  Widget _popup(TrainerEngine t) => GestureDetector(
        onTap: t.dismissPopup,
        child: Container(
          width: double.infinity, padding: const EdgeInsets.all(8), margin: const EdgeInsets.only(bottom: 4),
          decoration: BoxDecoration(color: const Color(0xFF4A1515), borderRadius: BorderRadius.circular(8)),
          child: Text('⚠ ${t.popup}', style: const TextStyle(color: Colors.white, fontSize: 12)),
        ),
      );

  Widget _tabs(Set<String> hl, {required bool pinned}) => DefaultTabController(
        length: 2,
        child: Column(children: [
          const TabBar(tabs: [Tab(text: 'MCDU'), Tab(text: 'CCD')], dividerHeight: 0),
          Expanded(
            child: TabBarView(physics: const BouncingScrollPhysics(), children: [
              McduKeypad(onKey: _onKey, highlights: hl, showLsk: !pinned),
              _ccd(),
            ]),
          ),
        ]),
      );

  Widget _ccd() => Column(children: [
        Expanded(flex: 4, child: CcdTouchPad(onMove: (d) => setState(() => cursor += d), onEnter: () => setState(() => lastCcd = 'CCD ENTER @ ${cursor.dx.round()},${cursor.dy.round()}'))),
        const SizedBox(height: 6),
        Expanded(flex: 6, child: ConcentricKnob(
          onOuter: (s) => setState(() => lastCcd = 'RANGE ${s > 0 ? '+' : '-'}'),
          onInner: (s) => setState(() => lastCcd = 'DATA ${s > 0 ? '+' : '-'}'),
          onPush: () => setState(() => lastCcd = 'PUSH ENTER'),
        )),
        SizedBox(height: 36, child: Row(children: [
          for (final d in ['PFD', 'MFD', 'EICAS'])
            Expanded(child: McduKey(id: d, glow: false, onPress: (_) => setState(() => lastCcd = 'DISPLAY: $d'))),
        ])),
        Text(lastCcd, style: const TextStyle(color: Colors.white38, fontSize: 11)),
      ]);
}
