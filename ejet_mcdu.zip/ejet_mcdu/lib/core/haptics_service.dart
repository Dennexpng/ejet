import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/services.dart';
import 'package:vibration/vibration.dart';

/// Haptics tuned for Samsung linear actuators (amplitude control when present)
/// plus cockpit click sounds. Put click.wav / detent.wav / error.wav in assets/audio/.
class Feedback {
  static final AudioPlayer _p = AudioPlayer()..setReleaseMode(ReleaseMode.stop);
  static bool? _amp;

  static Future<void> _buzz(int ms, int amplitude, VoidCallback fallback) async {
    _amp ??= (await Vibration.hasAmplitudeControl()) == true;
    if (_amp == true) {
      Vibration.vibrate(duration: ms, amplitude: amplitude);
    } else {
      fallback();
    }
  }

  static Future<void> _snd(String f) async {
    try { await _p.play(AssetSource('audio/$f')); } catch (_) {}
  }

  static void key() { _buzz(10, 70, HapticFeedback.lightImpact); _snd('click.wav'); }
  static void lsk() { _buzz(14, 110, HapticFeedback.mediumImpact); _snd('click.wav'); }
  static void detent() { _buzz(8, 50, HapticFeedback.selectionClick); _snd('detent.wav'); }
  static void push() { _buzz(22, 180, HapticFeedback.heavyImpact); _snd('click.wav'); }
  static void error() { _buzz(60, 220, HapticFeedback.vibrate); _snd('error.wav'); }
}
