import 'package:flutter/foundation.dart';
import '../models/simbrief_plan.dart';
import '../services/nav_database.dart';
import '../services/perf_tables.dart';

enum FmsPage { menu, posInit, fpln, perfInit, takeoff, depArr, radio, progress }
enum McduColor { green, cyan, magenta, white, amber, yellow }

class LskRow {
  final String lLabel, lData, rLabel, rData;
  final McduColor lColor, rColor;
  const LskRow({
    this.lLabel = '', this.lData = '', this.rLabel = '', this.rData = '',
    this.lColor = McduColor.cyan, this.rColor = McduColor.cyan,
  });
}

class McduFrame {
  final String title, pageNo, scratchpad;
  final String? message;
  final List<LskRow> rows; // always 6
  const McduFrame(this.title, this.pageNo, this.rows, this.scratchpad, this.message);
}

class Wpt {
  String ident;
  String via;
  int? alt;
  Wpt(this.ident, {this.via = 'DCT', this.alt});
}

/// (field, value, accepted) - used by the trainer for real-time validation.
typedef EntryHook = void Function(String field, String value, bool accepted);

class FmsState extends ChangeNotifier {
  FmsPage page = FmsPage.menu;
  int fplnPage = 0;
  String scratchpad = '';
  String? message;
  EntryHook? onEntry;
  NavDatabase? nav;      // optional: validates waypoints when loaded
  PerfTables? perfTables; // optional: replaces the training approximation

  // POS INIT
  String refAirport = '';
  String irs = 'OFF'; // OFF | ALIGNING | ALIGNED
  // FPLN
  String origin = '', dest = '';
  final List<Wpt> wpts = [];
  // PERF INIT
  String units = 'KGS';
  double? zfw, fuel, reserve;
  int? cruiseFt, costIndex;
  // TAKEOFF
  int? flaps, flexTemp;
  String? rating;
  int? v1, vr, v2, vfs;
  // DEP/ARR
  String depRwy = '', sid = '', trans = '', arrRwy = '', star = '';
  // RADIO
  String com1 = '118.000', com2 = '121.500', nav1 = '108.00', nav2 = '108.00';

  void _n() => notifyListeners();

  // ───────────── keys ─────────────
  void pressKey(String k) {
    message = null;
    switch (k) {
      case 'EXEC': _n(); return;
      case '→': _directTo(); return;
      case '←': pressKey('CLR'); return;
      case '+/-': _type('-'); return;
      case 'AIRP': case 'VOR': case 'NDB': case 'FIX': case 'LATLON':
        message = 'NOT AVAILABLE'; _n(); return;
      case 'MENU': _go(FmsPage.menu); return;
      case 'FPLN': _go(FmsPage.fpln); return;
      case 'PERF': _go(FmsPage.perfInit); return;
      case 'NAV': _go(FmsPage.depArr); return;
      case 'RADIO': _go(FmsPage.radio); return;
      case 'PROG': _go(FmsPage.progress); return;
      case 'INIT': _go(FmsPage.posInit); return;
      case 'NEXT': if (page == FmsPage.fpln) { fplnPage++; _clampFpln(); } _n(); return;
      case 'PREV': if (page == FmsPage.fpln) { fplnPage--; _clampFpln(); } _n(); return;
      case 'DIR': _directTo(); return;
      case 'CLR':
        if (scratchpad.isNotEmpty) { scratchpad = scratchpad.substring(0, scratchpad.length - 1); }
        _n(); return;
      case 'DEL': scratchpad = 'DELETE'; _n(); return;
      case 'SP': _type(' '); return;
      default:
        if (k.length == 1) _type(k);
    }
  }

  void _type(String c) {
    if (scratchpad == 'DELETE') scratchpad = '';
    if (scratchpad.length < 24) scratchpad += c;
    _n();
  }

  void clearHold() { scratchpad = ''; message = null; _n(); } // long-press CLR

  void _go(FmsPage p) { page = p; fplnPage = 0; _n(); }
  void _clampFpln() {
    final pages = _fplnPages;
    fplnPage = fplnPage.clamp(0, pages - 1);
  }
  int get _fplnPages => ((wpts.length + 1) / 4).ceil().clamp(1, 99);

  // ───────────── LSK dispatch ─────────────
  void pressLsk(bool left, int n) {
    message = null;
    if (left && n == 6 && page != FmsPage.menu) { _go(FmsPage.menu); return; } // <MCDU INDEX
    switch (page) {
      case FmsPage.menu: _lskMenu(left, n); break;
      case FmsPage.posInit: _lskPos(left, n); break;
      case FmsPage.fpln: _lskFpln(left, n); break;
      case FmsPage.perfInit: _lskPerf(left, n); break;
      case FmsPage.takeoff: _lskTakeoff(left, n); break;
      case FmsPage.depArr: _lskDepArr(left, n); break;
      case FmsPage.radio: _lskRadio(left, n); break;
      case FmsPage.progress: break;
    }
    _n();
  }

  void _lskMenu(bool l, int n) {
    final map = l
        ? {1: FmsPage.posInit, 2: FmsPage.depArr, 3: FmsPage.depArr, 4: FmsPage.fpln, 5: FmsPage.fpln, 6: FmsPage.perfInit}
        : {1: FmsPage.fpln, 2: FmsPage.depArr, 3: FmsPage.depArr, 6: FmsPage.radio};
    final p = map[n];
    if (p != null) _go(p);
  }

  // Generic scratchpad logic: empty -> pull current value; filled -> validate+commit.
  void _edit(String field, String current, bool Function(String) apply) {
    if (scratchpad.isEmpty) { scratchpad = current; return; }
    final v = scratchpad.trim().toUpperCase();
    if (v == 'DELETE') {
      final ok = apply('');
      onEntry?.call(field, 'DELETE', ok);
      if (ok) scratchpad = '';
      return;
    }
    final ok = apply(v);
    onEntry?.call(field, v, ok);
    if (ok) { scratchpad = ''; } else { message = 'INVALID ENTRY'; }
  }

  static bool _icao(String v) => RegExp(r'^[A-Z]{4}$').hasMatch(v);
  static bool _ident(String v) => RegExp(r'^[A-Z0-9]{2,5}$').hasMatch(v);
  static int? _alt(String v) {
    var s = v.replaceFirst('FL', '');
    final n = int.tryParse(s);
    if (n == null) return null;
    final ft = n < 1000 ? n * 100 : n;
    return (ft >= 0 && ft <= 41000) ? ft : null;
  }

  // POS INIT
  void _lskPos(bool l, int n) {
    if (l && n == 1) {
      _edit('refAirport', refAirport, (v) { if (!_icao(v)) return false; refAirport = v; return true; });
    } else if (!l && n == 1) {
      if (refAirport.isEmpty) { message = 'ENTER REF AIRPORT'; onEntry?.call('irs', 'ALIGN', false); return; }
      irs = 'ALIGNED'; // training: instant alignment
      onEntry?.call('irs', 'ALIGN', true);
    } else if (!l && n == 6) { _go(FmsPage.fpln); }
  }

  // FPLN
  void _lskFpln(bool l, int n) {
    if (fplnPage == 0 && n == 1) {
      if (l) { _edit('origin', origin, (v) { if (!_icao(v)) return false; origin = v; return true; }); }
      else { _edit('dest', dest, (v) { if (!_icao(v)) return false; dest = v; return true; }); }
      return;
    }
    if (n == 6 && !l) { _go(FmsPage.perfInit); return; }
    if (n < 2) return;
    final idx = fplnPage * 4 + (n - 2);
    if (l) {
      if (scratchpad == 'DELETE') {
        if (idx < wpts.length) { wpts.removeAt(idx); scratchpad = ''; onEntry?.call('wpt', 'DELETE', true); }
        else { message = 'INVALID DELETE'; }
      } else if (scratchpad.isEmpty) {
        if (idx < wpts.length) scratchpad = wpts[idx].ident;
      } else {
        final v = scratchpad.trim().toUpperCase();
        if (v == 'DISCO' || v == '-----') {
          wpts.insert(idx.clamp(0, wpts.length), Wpt('-----', via: 'DISCONTINUITY'));
          scratchpad = ''; onEntry?.call('wpt', v, true);
        } else if (_ident(v) && (nav == null || nav!.hasFix(v))) {
          wpts.insert(idx.clamp(0, wpts.length), Wpt(v));
          scratchpad = ''; onEntry?.call('wpt', v, true);
        } else { message = 'INVALID ENTRY'; onEntry?.call('wpt', v, false); }
      }
    } else if (idx < wpts.length) {
      _edit('wptAlt', '${wpts[idx].alt ?? ''}', (v) {
        if (v.isEmpty) { wpts[idx].alt = null; return true; }
        final a = _alt(v); if (a == null) return false; wpts[idx].alt = a; return true;
      });
    }
  }

  void _directTo() {
    final v = scratchpad.trim().toUpperCase();
    final i = wpts.indexWhere((w) => w.ident == v);
    if (i < 0) { message = 'NOT IN FPLN'; onEntry?.call('dct', v, false); _n(); return; }
    wpts.removeRange(0, i);
    scratchpad = ''; onEntry?.call('dct', v, true); _n();
  }

  // PERF INIT
  void _lskPerf(bool l, int n) {
    if (l && n == 1) _edit('zfw', zfw?.toStringAsFixed(0) ?? '', (v) { final x = double.tryParse(v); if (x == null || x < 10000 || x > 60000 * 2.3) return false; zfw = x; return true; });
    if (l && n == 2) _edit('fuel', fuel?.toStringAsFixed(0) ?? '', (v) { final x = double.tryParse(v); if (x == null || x < 0 || x > 40000) return false; fuel = x; return true; });
    if (l && n == 3) _edit('reserve', reserve?.toStringAsFixed(0) ?? '', (v) { final x = double.tryParse(v); if (x == null || x < 0) return false; reserve = x; return true; });
    if (!l && n == 1) _edit('cruise', cruiseFt == null ? '' : 'FL${cruiseFt! ~/ 100}', (v) { final a = _alt(v); if (a == null || a < 10000) return false; cruiseFt = a; return true; });
    if (!l && n == 2) _edit('ci', '${costIndex ?? ''}', (v) { final x = int.tryParse(v); if (x == null || x < 0 || x > 999) return false; costIndex = x; return true; });
    if (!l && n == 6) _go(FmsPage.takeoff);
  }

  // TAKEOFF
  void _lskTakeoff(bool l, int n) {
    if (l && n == 1) _edit('flaps', '${flaps ?? ''}', (v) { final x = int.tryParse(v); if (x == null || x < 1 || x > 4) return false; flaps = x; return true; });
    if (l && n == 2) _edit('rating', rating ?? '', (v) {
      final r = v.replaceAll('TO-', '').replaceAll('TO', '');
      if (r != '1' && r != '2') return false; rating = 'TO-$r'; return true; });
    if (l && n == 3) _edit('flex', '${flexTemp ?? ''}', (v) { final x = int.tryParse(v); if (x == null || x < 15 || x > 70) return false; flexTemp = x; return true; });
    if (!l && n >= 1 && n <= 4) {
      const names = ['v1', 'vr', 'v2', 'vfs'];
      final cur = [v1, vr, v2, vfs][n - 1];
      _edit(names[n - 1], '${cur ?? ''}', (v) {
        final x = int.tryParse(v); if (x == null || x < 80 || x > 200) return false;
        switch (n) { case 1: v1 = x; case 2: vr = x; case 3: v2 = x; default: vfs = x; }
        return true; });
    }
    if (!l && n == 5) _calcSpeeds();
    if (!l && n == 6) _go(FmsPage.depArr);
  }

  /// TRAINING-ONLY approximation - NOT real E-Jet AFM/FPM performance data.
  void _calcSpeeds() {
    if (zfw == null || fuel == null || flaps == null) {
      message = 'COMPLETE PERF + FLAPS'; onEntry?.call('speeds', '', false); return;
    }
    final k = units.startsWith('LB') ? 0.45359 : 1.0;
    final towKg = (zfw! + fuel! * 0.98) * k;
    final pt = perfTables;
    if (pt != null && pt.supports(flaps!)) {
      v1 = pt.speed(flaps!, 'v1', towKg); vr = pt.speed(flaps!, 'vr', towKg);
      v2 = pt.speed(flaps!, 'v2', towKg); vfs = pt.speed(flaps!, 'vfs', towKg);
      onEntry?.call('speeds', 'TABLE', true);
      return;
    }
    final towT = towKg / 1000.0;
    final flapAdj = (flaps! - 2) * -1; // more flap -> slightly lower speeds
    final v2s = (100 + towT * 1.0 + flapAdj).round().clamp(110, 165);
    v2 = v2s; v1 = v2s - 6; vr = v2s - 3; vfs = v2s + 22;
    onEntry?.call('speeds', 'CALC', true);
  }

  // DEP/ARR
  void _lskDepArr(bool l, int n) {
    if (l && n == 1) _edit('depRwy', depRwy, (v) { if (!RegExp(r'^\d{2}[LRC]?$').hasMatch(v)) return false; depRwy = v; return true; });
    if (l && n == 2) _edit('sid', sid, (v) { if (v.isNotEmpty && !_ident(v) && !RegExp(r'^[A-Z0-9]{3,8}$').hasMatch(v)) return false; sid = v; return true; });
    if (l && n == 3) _edit('trans', trans, (v) { trans = v; return true; });
    if (!l && n == 1) _edit('arrRwy', arrRwy, (v) { if (!RegExp(r'^\d{2}[LRC]?$').hasMatch(v)) return false; arrRwy = v; return true; });
    if (!l && n == 2) _edit('star', star, (v) { if (v.isNotEmpty && !RegExp(r'^[A-Z0-9]{3,8}$').hasMatch(v)) return false; star = v; return true; });
  }

  // RADIO
  void _lskRadio(bool l, int n) {
    bool com(String v) { final x = double.tryParse(v); return x != null && x >= 118 && x <= 136.975; }
    bool navf(String v) { final x = double.tryParse(v); return x != null && x >= 108 && x <= 117.95; }
    if (l && n == 1) _edit('com1', com1, (v) { if (!com(v)) return false; com1 = double.parse(v).toStringAsFixed(3); return true; });
    if (!l && n == 1) _edit('com2', com2, (v) { if (!com(v)) return false; com2 = double.parse(v).toStringAsFixed(3); return true; });
    if (l && n == 2) _edit('nav1', nav1, (v) { if (!navf(v)) return false; nav1 = double.parse(v).toStringAsFixed(2); return true; });
    if (!l && n == 2) _edit('nav2', nav2, (v) { if (!navf(v)) return false; nav2 = double.parse(v).toStringAsFixed(2); return true; });
  }

  // ───────────── SimBrief import ─────────────
  void importPlan(SimbriefPlan p) {
    origin = p.origin; dest = p.destination;
    refAirport = refAirport.isEmpty ? p.origin : refAirport;
    wpts..clear()..addAll(p.fixes.map((f) => Wpt(f.ident, via: f.via.isEmpty ? 'DCT' : f.via, alt: f.altFt)));
    units = p.units;
    zfw = p.zfw > 0 ? p.zfw : zfw;
    fuel = p.blockFuel > 0 ? p.blockFuel : fuel;
    reserve = p.reserve > 0 ? p.reserve : reserve;
    cruiseFt = p.cruiseAltFt > 0 ? p.cruiseAltFt : cruiseFt;
    costIndex = p.costIndex;
    depRwy = p.depRunway; arrRwy = p.arrRunway; sid = p.sid; star = p.star;
    fplnPage = 0;
    message = 'SIMBRIEF LOADED';
    onEntry?.call('import', p.origin, true);
    _n();
  }

  void reset() {
    final h = onEntry;
    final fresh = FmsState();
    page = FmsPage.menu; scratchpad = ''; message = null; fplnPage = 0;
    refAirport = ''; irs = 'OFF'; origin = ''; dest = ''; wpts.clear();
    zfw = fuel = reserve = null; cruiseFt = costIndex = null;
    flaps = flexTemp = null; rating = null; v1 = vr = v2 = vfs = null;
    depRwy = sid = trans = arrRwy = star = '';
    com1 = fresh.com1; com2 = fresh.com2; nav1 = fresh.nav1; nav2 = fresh.nav2;
    onEntry = h; _n();
  }

  // ───────────── frame builder ─────────────
  // Style follows the Honeywell MCDU: yellow = entry fields (▶ x / x ◀),
  // green = computed/active data, white = labels and menu lines.
  static const _box = '____';
  String _v(Object? v, [String box = _box]) => (v == null || '$v'.isEmpty) ? box : '$v';
  String _inL(Object? v, [String box = _box]) => '▶ ${_v(v, box)}';
  String _inR(Object? v, [String box = _box]) => '${_v(v, box)} ◀';

  McduFrame get frame {
    const y = McduColor.yellow, g = McduColor.green, w = McduColor.white;
    final rows = List<LskRow>.filled(6, const LskRow());
    var title = '';
    var pn = '1/1';
    void r(int i, LskRow row) => rows[i - 1] = row;

    switch (page) {
      case FmsPage.menu:
        {
          title = 'MCDU INDEX';
          pn = '';
          final l = ['STATUS', 'DEPARTURE', 'SID EDIT', 'ADD RTE WPTS', 'ROUTE EDIT', 'PERFORMANCE'];
          final rr = ['FLT PLAN', 'ARRIVAL', 'STAR EDIT', 'LOAD', 'SAVE', 'RADIOS'];
          for (var i = 0; i < 6; i++) {
            r(i + 1, LskRow(lData: '◀ ${l[i]}', lColor: w, rData: '${rr[i]} ▶', rColor: w));
          }
          break;
        }
      case FmsPage.posInit:
        title = 'POS INIT';
        r(1, LskRow(lLabel: 'REF AIRPORT', lData: _inL(refAirport), lColor: y, rLabel: 'IRS',
            rData: irs == 'ALIGNED' ? 'ALIGNED' : 'ALIGN ▶', rColor: irs == 'ALIGNED' ? g : w));
        r(2, LskRow(lLabel: 'IRS STATUS', lData: irs, lColor: irs == 'ALIGNED' ? g : McduColor.amber));
        r(6, const LskRow(rData: 'FLT PLAN ▶', rColor: w));
        break;
      case FmsPage.fpln:
        title = 'FLT PLAN';
        pn = '${fplnPage + 1}/$_fplnPages';
        if (fplnPage == 0) {
          r(1, LskRow(lLabel: 'ORIGIN', lData: _inL(origin), lColor: y, rLabel: 'DEST', rData: _inR(dest), rColor: y));
        }
        for (var n = 2; n <= 5; n++) {
          final idx = fplnPage * 4 + (n - 2);
          if (idx < wpts.length) {
            final wp = wpts[idx];
            r(n, LskRow(lLabel: wp.via, lData: wp.ident, lColor: wp.ident == '-----' ? w : g,
                rLabel: 'ALT', rData: wp.alt == null ? '' : _inR(wp.alt), rColor: y));
          } else if (idx == wpts.length) {
            r(n, LskRow(lData: _inL('', '_____'), lColor: y));
          }
        }
        r(6, const LskRow(rData: 'PERF INIT ▶', rColor: w));
        break;
      case FmsPage.perfInit:
        title = 'PERF: INIT';
        r(1, LskRow(lLabel: 'ZFW ($units)', lData: _inL(zfw?.toStringAsFixed(0)), lColor: y,
            rLabel: 'CRZ ALT', rData: _inR(cruiseFt == null ? null : 'FL${cruiseFt! ~/ 100}'), rColor: y));
        r(2, LskRow(lLabel: 'BLOCK FUEL', lData: _inL(fuel?.toStringAsFixed(0)), lColor: y,
            rLabel: 'COST INDEX', rData: _inR(costIndex), rColor: y));
        r(3, LskRow(lLabel: 'RESERVES', lData: _inL(reserve?.toStringAsFixed(0)), lColor: y));
        r(6, const LskRow(rData: 'TAKEOFF ▶', rColor: w));
        break;
      case FmsPage.takeoff:
        title = 'PERF: TAKEOFF';
        r(1, LskRow(lLabel: 'FLAPS', lData: _inL(flaps), lColor: y, rLabel: 'V1', rData: _v(v1, '___'), rColor: v1 == null ? y : g));
        r(2, LskRow(lLabel: 'RATING', lData: _inL(rating), lColor: y, rLabel: 'VR', rData: _v(vr, '___'), rColor: vr == null ? y : g));
        r(3, LskRow(lLabel: 'FLEX TEMP', lData: _inL(flexTemp), lColor: y, rLabel: 'V2', rData: _v(v2, '___'), rColor: v2 == null ? y : g));
        r(4, LskRow(rLabel: 'VFS', rData: _v(vfs, '___'), rColor: vfs == null ? y : g));
        r(5, const LskRow(rData: 'CALC SPEEDS ▶', rColor: w));
        r(6, const LskRow(rData: 'DEP/ARR ▶', rColor: w));
        break;
      case FmsPage.depArr:
        title = 'DEPARTURE / ARRIVAL';
        r(1, LskRow(lLabel: 'DEP RWY', lData: _inL(depRwy), lColor: y, rLabel: 'ARR RWY', rData: _inR(arrRwy), rColor: y));
        r(2, LskRow(lLabel: 'SID', lData: _inL(sid), lColor: y, rLabel: 'STAR', rData: _inR(star), rColor: y));
        r(3, LskRow(lLabel: 'TRANS', lData: _inL(trans, '-----'), lColor: y));
        break;
      case FmsPage.radio:
        title = 'RADIO';
        pn = '1/2';
        r(1, LskRow(lLabel: 'COM1', lData: _inL(com1), lColor: g, rLabel: 'COM2', rData: _inR(com2), rColor: g));
        r(2, LskRow(lLabel: 'NAV1', lData: _inL(nav1), lColor: g, rLabel: 'NAV2', rData: _inR(nav2), rColor: g));
        break;
      case FmsPage.progress:
        title = 'PROGRESS';
        r(1, LskRow(lLabel: 'ORIGIN', lData: _v(origin, '----'), lColor: g, rLabel: 'DEST', rData: _v(dest, '----'), rColor: g));
        break;
    }
    if (page != FmsPage.menu) {
      final o = rows[5];
      rows[5] = LskRow(lData: '◀ MCDU INDEX', lColor: w, rLabel: o.rLabel, rData: o.rData, rColor: o.rColor);
    }
    return McduFrame(title, pn, rows, scratchpad, message);
  }
}
