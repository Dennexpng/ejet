import 'package:flutter/foundation.dart';
import '../fms/fms_state_machine.dart';

class _Req {
  final bool Function(FmsState) done;
  final String key; // key id to highlight while this requirement is unmet
  const _Req(this.done, this.key);
}

class TrainerStep {
  final String title, instruction, pageKey;
  final FmsPage page;
  final Set<String> allowedFields;
  final List<_Req> reqs;
  const TrainerStep(this.title, this.instruction, this.page, this.pageKey,
      this.allowedFields, this.reqs);
  bool complete(FmsState f) => reqs.every((r) => r.done(f));
}

/// Guided E-Jet line-pilot preflight. Listens to FmsState; exposes
/// highlighted key ids (pulsing in UI), a banner, and error popups.
class TrainerEngine extends ChangeNotifier {
  final FmsState fms;
  int index = 0;
  String? popup;
  bool finished = false;

  TrainerEngine(this.fms) {
    fms.onEntry = _onEntry;
    fms.addListener(_check);
  }

  static final List<TrainerStep> steps = [
    TrainerStep('1/5  INIT / POS',
        'Press INIT. Type your REF AIRPORT ICAO on the keypad, press L1, then press R1 to align the IRS.',
        FmsPage.posInit, 'INIT', {'refAirport', 'irs'}, [
      _Req((f) => f.refAirport.length == 4, 'L1'),
      _Req((f) => f.irs == 'ALIGNED', 'R1'),
    ]),
    TrainerStep('2/5  ROUTE',
        'Open MCDU INDEX (L6) > FLT PLAN (R1). Tap SIMBRIEF to import your OFP, or type ORIGIN (L1), DEST (R1) and insert waypoints on L2-L5.',
        FmsPage.fpln, 'R1', {'import', 'origin', 'dest', 'wpt', 'wptAlt', 'dct'}, [
      _Req((f) => f.origin.isNotEmpty, 'L1'),
      _Req((f) => f.dest.isNotEmpty, 'R1'),
      _Req((f) => f.wpts.isNotEmpty, 'L2'),
    ]),
    TrainerStep('3/5  PERF INIT',
        'MCDU INDEX (L6) > PERFORMANCE (L6). Enter ZFW (L1), BLOCK FUEL (L2), RESERVES (L3), CRZ ALT (R1) and COST INDEX (R2).',
        FmsPage.perfInit, 'L6', {'zfw', 'fuel', 'reserve', 'cruise', 'ci'}, [
      _Req((f) => f.zfw != null, 'L1'),
      _Req((f) => f.fuel != null, 'L2'),
      _Req((f) => f.reserve != null, 'L3'),
      _Req((f) => f.cruiseFt != null, 'R1'),
      _Req((f) => f.costIndex != null, 'R2'),
    ]),
    TrainerStep('4/5  TAKEOFF DATA',
        'Go to TAKEOFF (R6 on PERF: INIT). Set FLAPS (L1), RATING TO-1/TO-2 (L2), FLEX TEMP (L3), then CALC SPEEDS (R5) for V1/VR/V2/VFS.',
        FmsPage.takeoff, 'R6', {'flaps', 'rating', 'flex', 'v1', 'vr', 'v2', 'vfs', 'speeds'}, [
      _Req((f) => f.flaps != null, 'L1'),
      _Req((f) => f.rating != null, 'L2'),
      _Req((f) => f.flexTemp != null, 'L3'),
      _Req((f) => f.v1 != null && f.vr != null && f.v2 != null && f.vfs != null, 'R5'),
    ]),
    TrainerStep('5/5  DEP / ARR',
        'MCDU INDEX (L6) > DEPARTURE (L2). Enter DEP RWY (L1), SID (L2), ARR RWY (R1) and STAR (R2).',
        FmsPage.depArr, 'L2', {'depRwy', 'sid', 'trans', 'arrRwy', 'star'}, [
      _Req((f) => f.depRwy.isNotEmpty, 'L1'),
      _Req((f) => f.sid.isNotEmpty, 'L2'),
      _Req((f) => f.arrRwy.isNotEmpty, 'R1'),
      _Req((f) => f.star.isNotEmpty, 'R2'),
    ]),
  ];

  TrainerStep get step => steps[index.clamp(0, steps.length - 1)];

  /// Key ids to pulse right now.
  Set<String> get highlights {
    if (finished) return {};
    final s = step;
    if (fms.page != s.page) {
      if (s.page == FmsPage.posInit) return {'INIT'};
      if (s.page == FmsPage.takeoff && fms.page == FmsPage.perfInit) return {'R6'};
      if (fms.page != FmsPage.menu) return {'L6'}; // <MCDU INDEX
      return {s.pageKey}; // line key on the MCDU INDEX page
    }
    for (final r in s.reqs) { if (!r.done(fms)) return {r.key, if (fms.scratchpad.isEmpty) 'ALPHANUM'}; }
    return {};
  }

  void _onEntry(String field, String value, bool accepted) {
    if (finished) return;
    if (!accepted) {
      popup = 'INVALID ENTRY for "$field": $value. Check format and range.';
    } else if (!step.allowedFields.contains(field)) {
      popup = '"$field" is not needed at this step. Follow the banner.';
    } else {
      popup = null;
    }
    notifyListeners();
  }

  void _check() {
    if (finished) return;
    if (step.complete(fms)) {
      if (index == steps.length - 1) { finished = true; popup = null; }
      else { index++; popup = null; }
    }
    notifyListeners();
  }

  void dismissPopup() { popup = null; notifyListeners(); }
  void restart() { index = 0; finished = false; popup = null; fms.reset(); notifyListeners(); }

  @override
  void dispose() {
    fms.removeListener(_check);
    fms.onEntry = null;
    super.dispose();
  }
}
