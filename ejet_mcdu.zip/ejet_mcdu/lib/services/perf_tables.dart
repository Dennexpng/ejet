import 'dart:convert';
import 'dart:io';

/// Takeoff speed tables you provide from your own licensed/AFM-derived data.
/// JSON: {"flaps":{"2":{"v1":[[40000,128],[45000,135]],"vr":[...],"v2":[...],"vfs":[...]}}}
/// Each series is [TOW_kg, knots]; linear interpolation, clamped at the ends.
class PerfTables {
  final Map<String, Map<String, List<List<double>>>> _t = {};

  static Future<PerfTables> loadFile(String path) async {
    final j = jsonDecode(await File(path).readAsString()) as Map<String, dynamic>;
    final out = PerfTables();
    (j['flaps'] as Map<String, dynamic>).forEach((flap, series) {
      out._t[flap] = {
        for (final e in (series as Map<String, dynamic>).entries)
          e.key: [for (final p in e.value as List) [(p[0] as num).toDouble(), (p[1] as num).toDouble()]]
            ..sort((a, b) => a[0].compareTo(b[0])),
      };
    });
    return out;
  }

  bool supports(int flaps) => _t.containsKey('$flaps');

  int? speed(int flaps, String which, double towKg) {
    final pts = _t['$flaps']?[which];
    if (pts == null || pts.isEmpty) return null;
    if (towKg <= pts.first[0]) return pts.first[1].round();
    if (towKg >= pts.last[0]) return pts.last[1].round();
    for (var i = 1; i < pts.length; i++) {
      if (towKg <= pts[i][0]) {
        final a = pts[i - 1], b = pts[i];
        return (a[1] + (b[1] - a[1]) * (towKg - a[0]) / (b[0] - a[0])).round();
      }
    }
    return null;
  }
}
