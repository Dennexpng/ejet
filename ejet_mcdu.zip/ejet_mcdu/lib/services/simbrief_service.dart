import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/simbrief_plan.dart';

class SimbriefException implements Exception {
  final String message;
  SimbriefException(this.message);
  @override
  String toString() => message;
}

/// Fetches the latest OFP via SimBrief's fetcher:
/// https://www.simbrief.com/api/xml.fetcher.php?userid=<ID>&json=1
/// Verify field names against your own OFP JSON; SimBrief occasionally changes them.
class SimbriefService {
  final http.Client _client;
  SimbriefService([http.Client? client]) : _client = client ?? http.Client();

  Future<SimbriefPlan> fetchLatest(String pilotId) async {
    final id = pilotId.trim();
    if (!RegExp(r'^\d{3,10}$').hasMatch(id)) {
      throw SimbriefException('Pilot ID must be numeric');
    }
    final uri = Uri.https('www.simbrief.com', '/api/xml.fetcher.php',
        {'userid': id, 'json': '1'});
    final http.Response r;
    try {
      r = await _client.get(uri).timeout(const Duration(seconds: 15));
    } catch (e) {
      throw SimbriefException('Network error: $e');
    }
    Map<String, dynamic>? j;
    try { j = jsonDecode(r.body) as Map<String, dynamic>; } catch (_) {}
    final status = '${j?['fetch']?['status'] ?? ''}';
    if (j == null) throw SimbriefException('SimBrief HTTP ${r.statusCode}');
    if (status != 'Success') {
      throw SimbriefException(status.isEmpty ? 'No OFP found' : status);
    }
    return SimbriefPlan.fromJson(j);
  }
}
