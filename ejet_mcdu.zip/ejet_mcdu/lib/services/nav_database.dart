import 'dart:io';

/// In-memory nav database loaded from X-Plane style files you supply
/// (earth_fix.dat, earth_nav.dat, e.g. from X-Plane or Navigraph exports).
/// No nav data is bundled: AIRAC data is licensed.
class NavPoint {
  final String ident;
  final double lat, lon;
  const NavPoint(this.ident, this.lat, this.lon);
}

class NavDatabase {
  final Map<String, List<NavPoint>> _byIdent = {};
  int get count => _byIdent.length;

  bool hasFix(String ident) => _byIdent.containsKey(ident.toUpperCase());
  List<NavPoint> lookup(String ident) => _byIdent[ident.toUpperCase()] ?? const [];

  void _add(NavPoint p) => (_byIdent[p.ident] ??= []).add(p);

  /// Parses fix and/or nav lines. Safe to call once per file.
  Future<void> loadFile(String path) async {
    final lines = await File(path).readAsLines();
    for (final raw in lines) {
      final t = raw.trim().split(RegExp(r'\s+'));
      if (t.length < 3) continue;
      final code = int.tryParse(t[0]);
      if (code != null && t.length >= 8 && (code == 2 || code == 3 || code == 12 || code == 13)) {
        // earth_nav.dat: code lat lon elev freq range var IDENT NAME...
        final lat = double.tryParse(t[1]), lon = double.tryParse(t[2]);
        if (lat != null && lon != null) _add(NavPoint(t[7].toUpperCase(), lat, lon));
      } else {
        // earth_fix.dat: lat lon IDENT ...
        final lat = double.tryParse(t[0]), lon = double.tryParse(t[1]);
        if (lat != null && lon != null) _add(NavPoint(t[2].toUpperCase(), lat, lon));
      }
    }
  }
}
