# E-Jet Primus Epic MCDU/CCD Trainer (Flutter)

## Directory tree
```
ejet_mcdu/
├─ pubspec.yaml
├─ assets/audio/            click.wav  detent.wav  error.wav  (add your own)
├─ android/app/src/main/AndroidManifest.xml   (add permissions below)
└─ lib/
   ├─ main.dart                       edge-to-edge, orientation, Provider root
   ├─ core/haptics_service.dart       Samsung amplitude haptics + audio
   ├─ models/simbrief_plan.dart       OFP JSON -> typed plan
   ├─ services/simbrief_service.dart  API fetcher
   ├─ fms/fms_state_machine.dart      pages, scratchpad, LSK logic, frame builder
   ├─ trainer/trainer_engine.dart     guided steps, highlights, validation popups
   ├─ widgets/mcdu_screen_widget.dart CustomPainter display + LSK columns
   ├─ widgets/ccd_touch_pad.dart      trackpad + concentric knobs
   ├─ widgets/mcdu_keys.dart          glowing keys + keypad
   └─ ui/home_screen.dart             portrait/landscape layouts, tabs, modes
```

## Build the APK (Android Studio)
1. Install Flutter SDK (3.22+), Android Studio, and the Flutter + Dart plugins.
2. In a terminal: `flutter create --org com.example --project-name ejet_mcdu .` inside this folder
   (generates the `android/` project without overwriting `lib/` or `pubspec.yaml`).
3. In `android/app/src/main/AndroidManifest.xml`, inside `<manifest>` add:
   `<uses-permission android:name="android.permission.INTERNET"/>` and
   `<uses-permission android:name="android.permission.VIBRATE"/>`.
4. Put `click.wav`, `detent.wav`, `error.wav` in `assets/audio/` (missing files are ignored safely).
5. `flutter pub get`, open the folder in Android Studio, select the S26 (USB debugging) or an emulator, press Run.
6. Release APK: `flutter build apk --release` → `build/app/outputs/flutter-apk/app-release.apk`.
   Sideload with `adb install`. For Play distribution use `flutter build appbundle` and a signing key.

## Notes / limits
- I haven't compiled or run this; expect to fix small analyzer errors on first build.
- SimBrief JSON field names (e.g. `general.sid_ident`) should be checked against your own OFP.
- V-speeds are a training approximation, not E-Jet AFM data; don't use for real operations.
- Honeywell/Embraer UI and fonts are trademarked/licensed; the look is an original approximation. Bundle a font you're licensed to use as `PrimusMono`.
- Page set is POS INIT, FPLN, PERF INIT, TAKEOFF, DEP/ARR, RADIO, PROGRESS; no real nav database, so waypoints are only validated by format.
